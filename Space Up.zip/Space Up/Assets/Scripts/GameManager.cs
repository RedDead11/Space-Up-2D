using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using UnityEngine.SocialPlatforms.Impl;

public class GameManager : MonoBehaviour
{
    private int score;

    public int PassingScore;

    public GameObject player;
    public GameObject gameOverSprite;

    public TextMeshProUGUI scoreText;

    public void GameOver()
    {
        Debug.Log("Game Over!");
        Destroy(player);
        gameOverSprite.SetActive(true);
        // Play same scene when player dies

        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
    public void IncreaseScore()
    {
        score++;
        scoreText.text = "Score: " + score;
    }

    //private void Update()
    //{
    //    // Levels Management

    //    if (score >= PassingScore)
    //    {
    //        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    //    }
    //}

    private void Update()
    {
        // Levels Management

        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        int nextSceneIndex = currentSceneIndex + 1;

        if (score >= PassingScore)
        {
            if (nextSceneIndex < SceneManager.sceneCountInBuildSettings)
            {
                SceneManager.LoadScene(nextSceneIndex);
            }
            else
            {
                SceneManager.LoadScene(0); // Load the first scene
            }
        }
    }
}
